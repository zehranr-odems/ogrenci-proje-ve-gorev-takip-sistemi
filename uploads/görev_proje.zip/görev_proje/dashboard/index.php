<?php
session_start();
include "../config/db.php";

$user_id = $_SESSION['user_id'];

$totalTasks = mysqli_num_rows(
mysqli_query($conn,
"SELECT * FROM tasks WHERE user_id='$user_id'")
);

$completedTasks = mysqli_num_rows(
mysqli_query($conn,
"SELECT * FROM tasks 
WHERE user_id='$user_id'
AND status='Tamamlandı'")
);

$pendingTasks = mysqli_num_rows(
mysqli_query($conn,
"SELECT * FROM tasks 
WHERE user_id='$user_id'
AND status='Bekliyor'")
);

$lateTasks = mysqli_num_rows(
mysqli_query($conn,
"SELECT * FROM tasks 
WHERE user_id='$user_id'
AND due_date < CURDATE()")
);

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<!-- SIDEBAR -->

<?php include "../includes/sidebar.php"; ?>
<script>
document.querySelectorAll('.menu a')[0].classList.add('active');
</script>

<!-- MAIN -->

<div class="main">

<?php include "../includes/topbar.php"; ?>
<div class="welcome-banner">

<div>

<h1>
Merhaba <?php echo $_SESSION['username']; ?> 👋
</h1>

<p>
Bugünkü görevlerini yönet ve projelerini takip et.
</p>

<a href="gorevler.php" class="add-btn">
    Yeni Görev Ekle
</a>

</div>

<div class="banner-icon">
🚀
</div>

</div>

<!-- CARDS -->

<div class="cards">


</div>


<div class="empty-box">
    Henüz görev eklenmedi 🌸
</div>

<div>
<?php include "../includes/footer.php"; ?>
</div>
<div>
<script src="../assets/js/app.js"></script>
</body>
</html>