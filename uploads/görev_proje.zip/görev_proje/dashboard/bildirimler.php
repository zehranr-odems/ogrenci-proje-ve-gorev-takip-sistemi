<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
}
?>

<!DOCTYPE html>
<html lang="tr">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Bildirimler</title>

<link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<?php include "../includes/sidebar.php"; ?>

<script>
document.querySelectorAll('.menu a')[5].classList.add('active');
</script>

<div class="main">

<?php include "../includes/topbar.php"; ?>

<div class="box">

<h2>Bildirimler 🔔</h2>

<div class="notification info">

<div class="empty-box">
    Bildirim bulunmuyor 🔔
</div>
</div>

<?php include "../includes/footer.php"; ?>

</div>

<script src="../assets/js/app.js"></script>

</body>
</html>