<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
}
?>

<!DOCTYPE html>
<html lang="tr">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Takvim</title>

<link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<?php include "../includes/sidebar.php"; ?>

<script>
document.querySelectorAll('.menu a')[3].classList.add('active');
</script>

<div class="main">

<?php include "../includes/topbar.php"; ?>

<div class="box">

<h2>Görev Takvimi 📅</h2>

<div class="calendar">

<div class="day-name">Pzt</div>
<div class="day-name">Sal</div>
<div class="day-name">Çar</div>
<div class="day-name">Per</div>
<div class="day-name">Cum</div>
<div class="day-name">Cmt</div>
<div class="day-name">Paz</div>

<div class="day">1</div>
<div class="day">2</div>

<div>3</div>

<div class="day">4</div>
<div class="day">5</div>

<div>6</div>

<div class="day">7</div>
<div class="day">8</div>
<div class="day">9</div>
<div class="day">10</div>
<div class="day">11</div>

<div>12</div>

<div class="day">13</div>
<div class="day">14</div>
<div class="day">15</div>
<div class="day">16</div>
<div class="day">17</div>
<div class="day">18</div>
<div class="day">19</div>
<div class="day">20</div>

</div>
<p class="calendar-note">Etkinlik bulunmuyor</p>
</div>

<?php include "../includes/footer.php"; ?>

</div>

<script src="../assets/js/app.js"></script>

</body>
</html>