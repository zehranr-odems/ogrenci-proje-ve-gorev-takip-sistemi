<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
}

include "../config/db.php";

$user_id = $_SESSION['user_id'];

$query = mysqli_query($conn,
"SELECT * FROM users WHERE id='$user_id'");

$user = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="tr">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Profilim</title>

<link rel="stylesheet" href="../assets/css/style.css">

</head>
<body>

<?php include "../includes/sidebar.php"; ?>

<script>
document.querySelectorAll('.menu a')[6].classList.add('active');
</script>

<div class="main">

<?php include "../includes/topbar.php"; ?>

<div class="box">

<div class="profile-box">

<div class="profile-image"></div>

<div>

<h2>
<?php echo $user['username']; ?>
</h2>

<p style="margin-top:10px; color:#777;">
<?php echo $user['email']; ?>
</p>

<p style="margin-top:10px; color:#d45c9d;">
Öğrenci Proje ve Görev Takip Sistemi Kullanıcısı
</p>

</div>

</div>

</div>

<div class="cards">

<div class="card">
<h3>Toplam Görev</h3>
<p>0</p>
</div>

<div class="card">
<h3>Tamamlanan</h3>
<p>0</p>
</div>

<div class="card">
<h3>Projeler</h3>
<p>0</p>
</div>

<div class="card">
<h3>Başarı Oranı</h3>
<p>%0</p>
</div>

</div>

<div class="box">

<h2>Hesap Ayarları</h2>

<div style="margin-top:20px;">

<input type="text"
value="<?php echo $user['username']; ?>">

<input type="email"
value="<?php echo $user['email']; ?>">

<button>
Profili Güncelle
</button>

</div>

</div>
<?php include "../includes/footer.php"; ?>
</div>

<script src="../assets/js/app.js"></script>

</body>
</html>