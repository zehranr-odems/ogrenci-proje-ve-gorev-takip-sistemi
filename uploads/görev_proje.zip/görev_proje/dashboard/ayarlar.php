<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
}
?>

<!DOCTYPE html>
<html lang="tr">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Ayarlar</title>

<link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<?php include "../includes/sidebar.php"; ?>

<script>
document.querySelectorAll('.menu a')[7].classList.add('active');
</script>

<div class="main">

<?php include "../includes/topbar.php"; ?>

<div class="box">

<h2>Ayarlar ⚙️</h2>

<div class="settings-grid">

<div class="setting-card">

<h3>Tema Ayarları</h3>

<p>
Aydınlık ve karanlık mod arasında geçiş yapabilirsiniz.
</p>

<button id="themeToggleBtn">
🌙 Tema Değiştir
</button>

</div>

<div class="setting-card">

<h3>Bildirimler</h3>

<p>
Görev ve proje bildirimlerini yönetebilirsiniz.
</p>

<label class="switch">

<input type="checkbox" checked>

<span class="slider"></span>

</label>

</div>

<div class="setting-card">

<h3>Gizlilik</h3>

<p>
Hesap görünürlüğü ve güvenlik ayarları.
</p>

<button>
Güvenlik Ayarları
</button>

</div>

</div>

</div>

<?php include "../includes/footer.php"; ?>

</div>

<script src="../assets/js/app.js"></script>

</body>
</html>