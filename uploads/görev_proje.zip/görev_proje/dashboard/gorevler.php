<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
}

$user_id = $_SESSION['user_id'];
if(isset($_GET['complete'])){

    $id = $_GET['complete'];

    mysqli_query($conn,
    "UPDATE tasks 
    SET status='Tamamlandı'
    WHERE id='$id'");
}

if(isset($_GET['delete'])){

    $id = $_GET['delete'];

    mysqli_query($conn,
    "DELETE FROM tasks
    WHERE id='$id'");
}

if(isset($_POST['add_task'])){

    $title = $_POST['title'];
    $due_date = $_POST['due_date'];

    $sql = "INSERT INTO tasks(user_id,title,due_date)
            VALUES('$user_id','$title','$due_date')";

    mysqli_query($conn,$sql);
}

$tasks = mysqli_query($conn,
"SELECT * FROM tasks WHERE user_id='$user_id' ORDER BY id DESC");

?>

<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Görevlerim</title>

<link rel="stylesheet" href="../assets/css/style.css">

</head>
<body>

<!-- SIDEBAR -->

<?php include "../includes/sidebar.php"; ?>
<script>
document.querySelectorAll('.menu a')[1].classList.add('active');
</script>
<!-- MAIN -->

<div class="main">
<?php include "../includes/topbar.php"; ?>

<div class="box">

<h2>Yeni Görev Ekle 🌸</h2>

<form method="POST">

<input type="text"
name="title"
placeholder="Görev Başlığı"
required>

<input type="date"
name="due_date"
required>

<button type="submit"
name="add_task">
Görev Ekle
</button>

</form>

</div>

<div class="box" style="margin-top:30px;">

<h2>Görevlerim</h2>
<div class="task-filters">

<button class="filter-btn active-filter">
Tümü
</button>

<button class="filter-btn">
Tamamlanan
</button>

<button class="filter-btn">
Bekleyen
</button>

<button class="filter-btn">
Geciken
</button>

</div>
<?php
if(mysqli_num_rows($tasks) == 0){
?>

<div class="empty-state">

<div class="empty-icon">
📝
</div>

<h2>
Henüz görev eklenmedi
</h2>

<p>
Yeni görev ekleyerek çalışmaya başlayabilirsin.
</p>

</div>

<?php
}
?>

<?php while($task = mysqli_fetch_assoc($tasks)) { ?>

<div class="task">

<h3><?php echo $task['title']; ?></h3>

<p>Teslim Tarihi:
<?php echo $task['due_date']; ?></p>

<?php

$statusClass = "pending";

if($task['status'] == "Tamamlandı"){
    $statusClass = "completed";
}

if(
$task['due_date'] < date("Y-m-d")
&& $task['status'] != "Tamamlandı"
){
    $statusClass = "late";
    $task['status'] = "Gecikti";
}

?>

<div class="status <?php echo $statusClass; ?>">
<?php echo $task['status']; ?>
</div>
<div style="margin-top:15px; display:flex; gap:10px;">

<a href="?complete=<?php echo $task['id']; ?>">
<button>
Tamamlandı
</button>
</a>

<script>
window.onload = () => {
showToast('Görev tamamlandı 🎉');
}
</script>


<a href="?delete=<?php echo $task['id']; ?>">
<button style="background:#ff6b81;">
Sil
</button>
</a>

<script>
window.onload = () => {
showToast('Görev silindi 🗑️');
}
</script>


</div>
</div>

<?php } ?>

</div>
<?php include "../includes/footer.php"; ?>
</div>

<script src="../assets/js/app.js"></script>
</body>
</html>